function addProgram(){
    const addProgramButton = document.querySelector('.addContainer');

    if(addProgramButton.style.display === 'none'){
        addProgramButton.style.display = 'block';
    } else{
        addProgramButton .style.display = 'none'
    }
}

function addProject(){
    const addProgramButton = document.querySelector('.addProject');

    if(addProgramButton.style.display === 'none'){
        addProgramButton.style.display = 'block';
    } else{
        addProgramButton .style.display = 'none'
    }
}

function editProgram(){
    const editProgramButton = document.querySelector('.editContainer');

    if(editProgramButton.style.display === 'none'){
        editProgramButton.style.display = 'block';
    } else{
        editProgramButton .style.display = 'none'
    }
}

function editProject(){
    const editProgramButton = document.querySelector('.editProject');

    if(editProgramButton.style.display === 'none'){
        editProgramButton.style.display = 'block';
    } else{
        editProgramButton .style.display = 'none'
    }
}

function popup12(){
    const popupButton = document.querySelector('.popup');

    if(popupButton.style.display === 'none'){
        popupButton.style.display = 'block';
    } else{
        popupButton .style.display = 'none'
    }
}