function triggerImageUpload() {
    document.getElementById('imageUpload').click();
}