function profile(){
  const profileButton = document.querySelector('.editContainer3');

  if(profileButton.style.display === 'none'){
      profileButton.style.display = 'block';
  } else{
      profileButton .style.display = 'none'
  }
}